/* eslint-disable no-undef */
/* eslint-disable no-console */
import React, { Component } from "react";
import "./components.css";
import Loader from "./Loader";
import PropTypes from "prop-types";
import Alerts from "./alerts/Alerts";
import TransitionsModal from "./modals/Modal";
const { REACT_APP_API_BASE_URL } = process.env;
import axios from "axios";

export class PdfComponent extends Component {
  //Handling prop types
  static propTypes = {
    getQueryId: PropTypes.func,
    Matches: PropTypes.object,
    getQueries: PropTypes.func,
  };
  constructor() {
    super();
    this.state = {
      name: "React",
      selectedFile: "",
      isLoading: false,
      showSuccessAlert: false,
      showFailAlert: false,
      getId: null,
      semanticHtmlString: "",
      MatchedResults: "",
      ClearMatchedResults: "",
      count: 0,
      isButtonDisabled: true,
      isModal: false,
      Alertseverity: "",
      AlertText: "",
      Alerttitle: "",
    };
    this.showFile = this.showFile.bind(this);
  }
  //Handling file change event
  showFile = (event) => {
    this.setState({
      selectedFile: event.target.files,
      isButtonDisabled: false,
    });
  };
  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    // eslint-disable-next-line no-unused-vars
    this.setState = (state, callback) => {
      return;
    };
  }
  //Handling Pdf input file via api
  async submitPdf() {
    this.setState({ isButtonDisabled: true });
    document.getElementById("show-text").innerHTML = "";

    const data = new FormData();
    data.append("files", this.state.selectedFile[0]);

    const url = `${REACT_APP_API_BASE_URL}/upload_convert_pdf_tables/`;

    const config = {
      headers: {
        "content-type": "multipart/form-data",
        Accept: "application/json",
        "Access-Control-Allow-Origin": "*",
      },
    };
    this.setState({
      isLoading: true,
    });
    await axios
      .post(url, data, config)
      .then((response) => {
        const myresponse = JSON.stringify(response.data);
        const content = Object.values(JSON.parse(myresponse));
        const myarray = Array.from(content[0].map((value) => value.query));

        const chordsArray = myarray;
        this.props.getQueries(myarray);
        const container = document.getElementById("show-text");

        // Creating Dynamic div elements with ids
        for (let i = 0; i < chordsArray.length; i += 1) {
          const chord = document.createElement("div");
          chord.className = "Queries list-item ";

          //highlight active list
          $(".list-item").click(function () {
            // Select all list items
            const listItems = $(".list-item");

            // Remove 'active' tag for all list items
            for (let i = 0; i < listItems.length; i++) {
              listItems[i].classList.remove("activelist");
            }

            // Add 'active' tag for currently selected item
            this.classList.add("activelist");
          });
          //chord id
          chord.id = i;

          //semantic search Results based on Matches
          chord.onclick = async () => {
            try {
              const k = chord.id;
              console.log(this.props.Matches);

              for (let i = 0; i < this.props.Matches[`q_${k}`].length; i++) {
                const temp = `q_${k}`;
                console.log(temp, "temp");

                document.getElementById(
                  `${this.props.Matches[`q_${k}`][i]}`
                ).style.backgroundColor = "#73C2FB";
                document
                  .getElementById(`${this.props.Matches[`q_${k}`][i]}`)
                  .scrollIntoView({ behavior: "smooth" });
                this.setState({
                  count: 1,
                });
                console.log(`${this.props.Matches[`q_${k}`][i]}`, "matches i");
              }
              this.props.getQueryId(chord.id);
            } catch (error) {
              this.setState({
                showFailAlert: true,
                Alerttitle: "Oops ",
                Alertseverity: "warning",
                AlertText: "Load Docx file and hit search to map the results",
              });
              const timer = setTimeout(() => {
                this.setState({
                  showFailAlert: false,
                });
                clearTimeout(timer);
              }, 2000);
            }
          };

          const textNode = document.createTextNode("This is div #" + i);
          chord.appendChild(textNode);
          chord.innerText = chordsArray[i];
          this.setState({
            isLoading: false,
          });
          container.appendChild(chord);
        }
        this.setState({
          showSuccessAlert: true,
          Alerttitle: "Success ",
          Alertseverity: "success",
          AlertText: "File loaded successfully!",
        });
        const timer = setTimeout(() => {
          this.setState({
            showSuccessAlert: false,
          });
          clearTimeout(timer);
        }, 2000);
      })
      .catch((err) => {
        this.setState({
          showFailAlert: true,
          isLoading: false,
          isButtonDisabled: false,
          Alerttitle: "Error ",
          Alertseverity: "error",
          AlertText: "Reload file again !",
        });

        const timer = setTimeout(() => {
          this.setState({
            showFailAlert: false,
          });
          clearTimeout(timer);
        }, 2000);
        console.log(err);
      });
  }

  render = () => {
    return (
      <div className="">
        {this.state.isModal && <TransitionsModal text="Searching ..." />}
        {this.state.showSuccessAlert && (
          <Alerts
            Alertseverity={this.state.Alertseverity}
            AlertText={this.state.AlertText}
            Alerttitle={this.state.Alerttitle}
          ></Alerts>
        )}
        {this.state.showFailAlert && (
          <Alerts
            Alertseverity={this.state.Alertseverity}
            AlertText={this.state.AlertText}
            Alerttitle={this.state.Alerttitle}
          />
        )}

        <input type="file" onChange={this.showFile} name="files" multiple />

        <button
          type="submit"
          className="btn btn-info"
          style={{ marginLeft: "70px", float: "right" }}
          onClick={() => this.submitPdf()}
          disabled={this.state.isButtonDisabled}
          data-toggle="tooltip"
          data-placement="bottom"
          title="Submit"
        >
          Submit
        </button>

        <div
          className=""
          style={{
            paddingLeft: "20px",
            paddingRight: "10px",
            paddingTop: "20px",
            paddingBottom: "20px",
            height: "  580px",
            overflowY: "auto",
          }}
          id="show-text"
        >
          {" "}
          {/* <button className="to">Edit</button> */}
          {this.state.isLoading && <Loader />}
        </div>
      </div>
    );
  };
}

export default PdfComponent;

// /* eslint-disable no-undef */
// /* eslint-disable no-console */
// import React, { Component } from "react";
// import "./components.css";
// import Loader from "./Loader";
// import PropTypes from "prop-types";
// import Alerts from "./alerts/Alerts";
// import TransitionsModal from "./modals/Modal";
// const { REACT_APP_API_BASE_URL } = process.env;
// import axios from "axios";

// export class PdfComponent extends Component {
//   static propTypes = {
//     // getQueryId: PropTypes.func,
//     // Matches: PropTypes.object,
//     getQueries: PropTypes.func,
//   };
//   constructor() {
//     super();
//     this.state = {
//       name: "React",
//       selectedFile: "",
//       isLoading: false,
//       showSuccessAlert: false,
//       showFailAlert: false,
//       getId: null,
//       semanticHtmlString: "",
//       MatchedResults: "",
//       ClearMatchedResults: "",
//       count: 0,
//       isButtonDisabled: true,
//       isModal: false,
//       Alertseverity: "",
//       AlertText: "",
//       Alerttitle: "",
//       Queries: [],
//     };
//     this.showFile = this.showFile.bind(this);
//   }

//   showFile = (event) => {
//     this.setState({
//       selectedFile: event.target.files,
//       isButtonDisabled: false,
//     });

//     if (window.File && window.FileReader && window.FileList && window.Blob) {
//       const preview = document.getElementById("show-text");
//       const file = document.querySelector("input[type=file]").files[0];
//       const reader = new FileReader();

//       const textFile = /text.*/;

//       if (file.type.match(textFile)) {
//         reader.onload = function (event) {
//           preview.innerHTML = event.target.result;
//         };
//       } else {
//         // preview.innerHTML =
//         //   "<span class='error'>It doesn't seem to be a text file! Please Click on submit to read the document .</span>";
//       }
//       reader.readAsText(file);
//     } else {
//       alert("Your browser is too old to support HTML5 File API");
//     }
//   };
//   componentWillUnmount() {
//     // fix Warning: Can't perform a React state update on an unmounted component
//     // eslint-disable-next-line no-unused-vars
//     this.setState = (state, callback) => {
//       return;
//     };
//   }
//   async submitpdf() {
//     this.setState({ isButtonDisabled: true });
//     document.getElementById("show-text").innerHTML = "";

//     const data = new FormData();
//     data.append("files", this.state.selectedFile[0]);

//     const url = `${REACT_APP_API_BASE_URL}/upload_convert_pdf_tables/`;

//     const config = {
//       headers: {
//         "content-type": "multipart/form-data",
//         Accept: "application/json",
//         "Access-Control-Allow-Origin": "*",
//       },
//     };
//     this.setState({
//       isLoading: true,
//     });
//     await axios
//       .post(url, data, config)
//       .then((response) => {
//         const myresponse = JSON.stringify(response.data);
//         const content = Object.values(JSON.parse(myresponse));
//         const myarray = Array.from(content[0]);

//         // const chordsArray = myarray;
//         this.props.getQueries(myarray);

//         this.setState({
//           Queries: myarray,
//         });

//         this.setState({
//           isLoading: false,
//         });
//         // const container = document.getElementById("show-text");

//         // for (let i = 0; i < chordsArray.length; i += 1) {
//         //   const chord = document.createElement("div");
//         //   chord.className = "Queries list-item ";

//         //   //highlight active list
//         //   $(".list-item").click(function () {
//         //     // Select all list items
//         //     const listItems = $(".list-item");

//         //     // Remove 'active' tag for all list items
//         //     for (let i = 0; i < listItems.length; i++) {
//         //       listItems[i].classList.remove("activelist");
//         //     }

//         //     // Add 'active' tag for currently selected item
//         //     this.classList.add("activelist");
//         //   });
//         //   //chord id
//         //   chord.id = i;

//         //   //semantic search api request
//         //   chord.onclick = async () => {
//         //     try {
//         //       const k = chord.id;
//         //       console.log(this.props.Matches);

//         //       for (let i = 0; i < this.props.Matches[`q_${k}`].length; i++) {
//         //         const temp = `q_${k}`;
//         //         console.log(temp, "temp");

//         //         document.getElementById(
//         //           `${this.props.Matches[`q_${k}`][i]}`
//         //         ).style.backgroundColor = "#73C2FB";
//         //         document
//         //           .getElementById(`${this.props.Matches[`q_${k}`][i]}`)
//         //           .scrollIntoView({ behavior: "smooth" });
//         //         this.setState({
//         //           count: 1,
//         //         });
//         //         console.log(`${this.props.Matches[`q_${k}`][i]}`, "matches i");
//         //       }
//         //       this.props.getQueryId(chord.id);
//         //     } catch (error) {
//         //       this.setState({
//         //         showFailAlert: true,
//         //         Alerttitle: "Oops ",
//         //         Alertseverity: "warning",
//         //         AlertText: "Load Docx file and hit search to map the results",
//         //       });
//         //       const timer = setTimeout(() => {
//         //         this.setState({
//         //           showFailAlert: false,
//         //         });
//         //         clearTimeout(timer);
//         //       }, 2000);
//         //     }
//         //   };

//         //   const textnode = document.createTextNode("This is div #" + i);
//         //   chord.appendChild(textnode);
//         //   chord.innerText = chordsArray[i];
//         //   this.setState({
//         //     isLoading: false,
//         //   });
//         //   container.appendChild(chord);
//         // }
//         // this.setState({
//         //   showSuccessAlert: true,
//         //   Alerttitle: "Success ",
//         //   Alertseverity: "success",
//         //   AlertText: "File loaded successfully!",
//         // });
//         // const timer = setTimeout(() => {
//         //   this.setState({
//         //     showSuccessAlert: false,
//         //   });
//         //   clearTimeout(timer);
//         // }, 2000);
//       })
//       .catch((err) => {
//         this.setState({
//           showFailAlert: true,
//           isLoading: false,
//           isButtonDisabled: false,
//           Alerttitle: "Error ",
//           Alertseverity: "error",
//           AlertText: "Reload file again !",
//         });

//         const timer = setTimeout(() => {
//           this.setState({
//             showFailAlert: false,
//           });
//           clearTimeout(timer);
//         }, 2000);
//         console.log(err);
//       });
//   }
//   edit = async () => {
//     alert("edit");
//   };
//   render = () => {
//     return (
//       <div className="">
//         {this.state.isModal && <TransitionsModal text="Searching ..." />}
//         {this.state.showSuccessAlert && (
//           <Alerts
//             Alertseverity={this.state.Alertseverity}
//             AlertText={this.state.AlertText}
//             Alerttitle={this.state.Alerttitle}
//           ></Alerts>
//         )}
//         {this.state.showFailAlert && (
//           <Alerts
//             Alertseverity={this.state.Alertseverity}
//             AlertText={this.state.AlertText}
//             Alerttitle={this.state.Alerttitle}
//           />
//         )}

//         <input type="file" onChange={this.showFile} name="files" multiple />

//         <button
//           type="submit"
//           className="btn btn-info"
//           style={{ marginLeft: "70px", float: "right" }}
//           onClick={() => this.submitpdf()}
//           disabled={this.state.isButtonDisabled}
//         >
//           Submit
//         </button>

//         <div
//           className=""
//           style={{
//             paddingLeft: "20px",
//             paddingRight: "10px",
//             paddingTop: "20px",
//             paddingBottom: "20px",
//             height: "  580px",
//             overflowY: "auto",
//           }}
//           id="show-text"
//         >
//           {" "}
//           {/* <button className="to">Edit</button> */}
//           {this.state.Queries.map((item, i) => (
//             // eslint-disable-next-line react/jsx-key
//             <div className={`${i} results`} key={i}>
//               {item.query}
//               <button id="edit" onClick={this.edit}>
//                 Comment
//               </button>
//             </div>
//           ))}
//           {this.state.isLoading && <Loader />}
//         </div>
//       </div>
//     );
//   };
// }

// export default PdfComponent;
