/* eslint-disable no-undef */
/* eslint-disable no-console */
import React, { Component } from "react";

import "./components.css";
import "react-summernote/dist/react-summernote.css"; // import styles
import "bootstrap/js/dist/modal";
import "bootstrap/js/dist/dropdown";
import "bootstrap/js/dist/tooltip";
import "bootstrap/dist/css/bootstrap.css";
import Loader from "./Loader";
window.Popper = require("popper.js").default;
window.$ = window.jQuery = require("jquery");
require("bootstrap");
import Alerts from "./alerts/Alerts";
const { REACT_APP_API_BASE_URL } = process.env;

class DocxComponent extends Component {
  constructor() {
    super();
    this.state = {
      name: "React",
      selectedFile: "",
      content1: "",
      fileBase64String: "",
      isLoading: false,
      showSuccessAlert: false,
      showFailAlert: false,
      isButtonDisabled: true,
      Alertseverity: "",
      AlertText: "",
      Alerttitle: "",
    };
    this.showFile = this.showFile.bind(this);
  }

  //  handles input files
  showFile = (e) => {
    this.setState({
      selectedFile: e.target.files,
      isButtonDisabled: false,
    });
    //should be explicitly handled
    e.preventDefault();

    //a filereader object is created using a filereader constructor
    const reader = new FileReader();

    //readasarraybuffer will read the file
    reader.readAsArrayBuffer(e.target.files[0]);
  };
  
  //submitDocx handles docx file and coverts into queries via api
  async submitDocx() {
    this.setState({ isButtonDisabled: true });
    document.getElementById("show-text").innerHTML = "";
    const axios = require("axios");
    const FormData = require("form-data");
    const data = new FormData();
    data.append("file", this.state.selectedFile[0]);
    const config = {
      method: "post",
      url: `${REACT_APP_API_BASE_URL}/docx_to_queries/`,
      headers: {
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
      },
      data: data,
    };

    try {
      this.setState({
        isLoading: true,
      });
      const response = await axios(config);
      console.log(response, "try");

      if (response.status === 200) {
        const myresponse = JSON.stringify(response.data);

        const content = Object.values(JSON.parse(myresponse));
        const myarray = Array.from(content[0].map((value) => value.query));

        //myarray contains the queried text
        const chordsArray = myarray;
        const container = document.getElementById("show-text");

        // Creating Dynamic div elements with ids
        for (let i = 0; i < chordsArray.length; i += 1) {
          const chord = document.createElement("div");
          chord.className = "Queries";
          chord.id = "Query" + i;
          //TextNode objects contain only text content without any HTML or XML markup.
          // TextNode objects make it possible to insert texts into the document as nodes
          const textnode = document.createTextNode("This is div #" + i);
          chord.appendChild(textnode);

          // chord.className = "chord";
          chord.innerText = chordsArray[i];
          this.setState({
            isLoading: false,
          });
          container.appendChild(chord);
        }
        this.setState({
          showSuccessAlert: true,
          isLoading: false,
          Alerttitle: "Success ",
          Alertseverity: "success",
          AlertText: "File loaded successfully!",
        });
        const timer = setTimeout(() => {
          this.setState({
            showSuccessAlert: false,
          });
          clearTimeout(timer);
        }, 2000);
      }
    } catch (err) {
      this.setState({
        showFailAlert: true,
        isLoading: false,
        isButtonDisabled: false,
        Alerttitle: "Error ",
        Alertseverity: "error",
        AlertText: "Reload file again !",
      });

      const timer = setTimeout(() => {
        this.setState({
          showFailAlert: false,
        });
        clearTimeout(timer);
      }, 2000);
      console.log(err);
    }
  }

  render = () => {
    return (
      <div className="">
        {this.state.showSuccessAlert && (
          <Alerts
            Alertseverity={this.state.Alertseverity}
            AlertText={this.state.AlertText}
            Alerttitle={this.state.Alerttitle}
          ></Alerts>
        )}
        {this.state.showFailAlert && (
          <Alerts
            Alertseverity={this.state.Alertseverity}
            AlertText={this.state.AlertText}
            Alerttitle={this.state.Alerttitle}
          />
        )}
        <input type="file" onChange={this.showFile} name="files" multiple />

        <button
          type="submit"
          className="btn btn-info"
          style={{ marginLeft: "70px", float: "right" }}
          onClick={() => this.submitDocx()}
          disabled={this.state.isButtonDisabled}
          data-toggle="tooltip"
          data-placement="bottom"
          title="Submit"
        >
          Submit
        </button>

        <div
          className=""
          style={{
            paddingLeft: "20px",
            paddingRight: "10px",
            paddingTop: "20px",
            paddingBottom: "20px",
            height: "  580px",
            overflowY: "auto",
          }}
          id="show-text"
        >
          {this.state.isLoading && <Loader />}
        </div>
      </div>
    );
  };
}

export default DocxComponent;
