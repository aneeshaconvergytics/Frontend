import React, { Component } from "react";

export default class SignupDone extends Component {
  render() {
    return (
      <h3 className="mx-5">
        Thanks for your registration, please follow the link sent to your
        provided email to activate your account.
      </h3>
    );
  }
}
