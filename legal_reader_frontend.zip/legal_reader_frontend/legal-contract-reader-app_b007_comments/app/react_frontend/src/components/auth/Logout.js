import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { logoutUser } from "../../actions/authActions";
import history from "../../utils/historyUtils";

class Logout extends Component {
  static propTypes = {
    logoutUser: PropTypes.func.isRequired,
  };

  componentDidMount() {
    this.props.logoutUser();
    window.addEventListener("storage", localStorage.clear(), false);

    history.push("/login");
  }

  render() {
    return <h2>Sorry to see you go...</h2>;
  }
}

export default connect(null, { logoutUser })(Logout);
