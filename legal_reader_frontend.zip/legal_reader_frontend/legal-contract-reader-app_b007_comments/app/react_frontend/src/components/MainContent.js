import React from "react";
import { Switch, Route } from "react-router-dom";
import RequireAuth from "./auth/RequireAuth";
import Landing from "./Landing";
import Login from "./auth/Login";
import Logout from "./auth/Logout";
import Signup from "./auth/Signup";
import SignupDone from "./auth/SignupDone";
import AccountActivation from "./auth/AccountActivation";
import UserProfile from "./auth/UserProfile";
import UserProfileEdit from "./auth/UserProfileEdit";
import PasswordChange from "./auth/PasswordChange";
import PasswordReset from "./auth/PasswordReset";
import PasswordResetDone from "./auth/PasswordResetDone";
import PasswordResetConfirm from "./auth/PasswordResetConfirm";
import NoMatch from "./NoMatch";
import WordEditor from "./WordEditor";
import WordEditorDocx from "./WordEditorDocx";
import WordEditorPdf from "./WordEditorPdf";
import WordEditorDocxv1 from "./WordEditorDocxv1";

const MainContent = () => (
  <div>
    <Switch>
      <Route exact path="/" component={RequireAuth(Landing)} />
      <Route path="/login" component={Login} />
      <Route path="/logout" component={Logout} />
      <Route path="/signup" component={Signup} />
      <Route path="/account/confirm-email/:key" component={AccountActivation} />
      <Route path="/signup_done" component={SignupDone} />
      <Route path="/reset_password" component={PasswordReset} />
      <Route path="/reset_password_done" component={PasswordResetDone} />
      <Route path="/reset/:uid/:token/" component={PasswordResetConfirm} />
      <Route path="/profile" component={RequireAuth(UserProfile)} />
      <Route path="/profile_edit" component={RequireAuth(UserProfileEdit)} />
      <Route path="/change_password" component={RequireAuth(PasswordChange)} />
      <Route path="/text" component={RequireAuth(WordEditor)} />
      <Route path="/docx" component={RequireAuth(WordEditorDocx)} />
      <Route path="/docxv1" component={RequireAuth(WordEditorDocxv1)} />
      <Route path="/pdf" component={RequireAuth(WordEditorPdf)} />
      <Route component={NoMatch} />
    </Switch>
  </div>
);

export default MainContent;
