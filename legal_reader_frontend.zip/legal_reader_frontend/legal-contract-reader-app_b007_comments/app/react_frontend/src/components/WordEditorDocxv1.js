import React from "react";
import { Row, Col, Card, CardBody } from "reactstrap";
import DocxComponentv1 from "./DocxComponentv1";
import "../index.css";
import { Link } from "react-router-dom";
import WordEditorRight from "./WordEditorRight";

const WordEditorDocxv1 = () => {
  return (
    <Card
      style={{
        border: "1px solid #c9c9c9",
        width: "100%",
        display: "inline-flex",
      }}
    >
      <CardBody className="rdt_Wrapper shadow">
        <Row>
          <Col sm="12" md="6">
            <div className="card shadow" style={{ padding: "10px" }}>
              <div>
                <Link
                  className="btn btn-Light"
                  to="/text"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Text File
                </Link>
                <Link
                  to="/docx"
                  className="btn btn-Light"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Docx File
                </Link>{" "}
                <Link
                  to="/docxv1"
                  className="btn btn-info"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Docx File V1
                </Link>{" "}
                <Link
                  to="/pdf"
                  className="btn btn-Light"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",

                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  PDF File
                </Link>{" "}
              </div>
              <DocxComponentv1 />
            </div>
          </Col>
          <Col sm="12" md="6">
            <div className="card shadow">
              <WordEditorRight />
            </div>
          </Col>
        </Row>
      </CardBody>
    </Card>
  );
};

export default WordEditorDocxv1;
