import React, { Component } from "react";
import PropTypes from "prop-types";
import WordEditor from "./WordEditor";
import Footer from "./Footer";
export class Landing extends Component {
  static propTypes = {
    authenticated: PropTypes.bool,
  };
  render() {
    return (
      <React.Fragment>
        {this.props.authenticated ? (
          <WordEditor />
        ) : (
          <div style={{ height: "100vh" }}>
            <h1
              style={{
                marginTop: "200px",
                height: "400px",
                textAlign: "center",
              }}
            >
              {" "}
              WELCOME TO CONTRACT MAPPER !
            </h1>
            <Footer />
          </div>
        )}
      </React.Fragment>
    );
  }
}

export default Landing;
