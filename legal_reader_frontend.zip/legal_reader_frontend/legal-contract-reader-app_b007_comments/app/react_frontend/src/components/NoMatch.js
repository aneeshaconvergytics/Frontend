import React from "react";

const NoMatch = () => (
    <h2 className="mt-2">{"Sorry, the page you are looking for doesn't exist."}</h2>
);

export default NoMatch;
