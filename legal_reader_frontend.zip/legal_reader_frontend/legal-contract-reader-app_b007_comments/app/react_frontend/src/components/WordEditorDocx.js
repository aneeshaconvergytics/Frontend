import React from "react";
import { Row, Col, Card, CardBody } from "reactstrap";
import DocxComponent from "./DocxComponent";
import "../index.css";
import { Link } from "react-router-dom";
import WordEditorRight from "./WordEditorRight";

const WordEditorDocx = () => {
  return (
    <Card
      style={{
        border: "1px solid #c9c9c9",
        width: "100%",
        display: "inline-flex",
      }}
    >
      <CardBody className="rdt_Wrapper shadow">
        <Row>
          <Col sm="12" md="6">
            <div className="card shadow" style={{ padding: "10px" }}>
              <div>
                <Link
                  className="btn btn-Light"
                  to="/text"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Text File
                </Link>
                <Link
                  to="/docx"
                  className="btn btn-info"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Docx File
                </Link>{" "}
                <Link
                  to="/docxv1"
                  className="btn btn-Light"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",
                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  Docx File V1
                </Link>{" "}
                <Link
                  to="/pdf"
                  className="btn btn-Light"
                  style={{
                    paddingRight: "21px",
                    paddingLeft: "20px",

                    marginTop: "4px",
                    marginBottom: "10px",
                  }}
                >
                  PDF File
                </Link>{" "}
              </div>
              <DocxComponent />
            </div>
          </Col>
          <Col sm="12" md="6">
            <div className="card shadow">
              <WordEditorRight />
            </div>
          </Col>
        </Row>
      </CardBody>
    </Card>
  );
};

export default WordEditorDocx;
