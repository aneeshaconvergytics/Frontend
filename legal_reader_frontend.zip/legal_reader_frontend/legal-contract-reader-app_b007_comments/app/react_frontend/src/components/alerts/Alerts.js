/* eslint-disable react/prop-types */
import * as React from "react";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";
import AlertTitle from "@mui/material/AlertTitle";

export default function Alerts({ Alertseverity, AlertText, Alerttitle }) {
  return (
    <Stack sx={{ width: "100%" }} spacing={2}>
      <Alert severity={Alertseverity}>
        <AlertTitle>{Alerttitle} </AlertTitle>
        <strong>{AlertText} </strong>
      </Alert>
    </Stack>
  );
}
