import React, { Component } from "react";
import RightHandEditor1 from "./RightHandEditor1";
import PropTypes from "prop-types";

export class WordEditorRight extends Component {
  static propTypes = {
    queryId: PropTypes.string,
    Queries: PropTypes.array,
    getMatches: PropTypes.func,
  };
  render() {
    return (
      <div>
        <RightHandEditor1
          queryId={this.props.queryId}
          Queries={this.props.Queries}
          getMatches={this.props.getMatches}
        />
      </div>
    );
  }
}

export default WordEditorRight;
