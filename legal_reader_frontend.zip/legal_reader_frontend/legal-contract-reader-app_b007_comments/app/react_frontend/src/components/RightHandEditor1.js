/* eslint-disable react/no-danger-with-children */
// /* eslint-disable no-unused-vars */
// /* eslint-disable no-undef */
// /* eslint-disable no-console */
// import React, { Component } from "react";
// import { saveAs } from "file-saver";
// import "../index.css";
// import "./components.css";

// window.Popper = require("popper.js").default;
// window.$ = window.jQuery = require("jquery");
// const he = require("he");
// import Loader from "./Loader";
// import TransitionsModal from "./modals/Modal";
// import PropTypes from "prop-types";
// import Alerts from "./alerts/Alerts";
// const { REACT_APP_API_BASE_URL } = process.env;
// class RightHandEditor1 extends Component {
//   static propTypes = {
//     queryId: PropTypes.string,
//     Queries: PropTypes.array,
//     getMatches: PropTypes.func,
//   };
//   constructor() {
//     super();
//     this.state = {
//       name: "React",
//       value: "",
//       selectedFile: "",
//       content1: "",
//       fileBase64String: "",
//       isLoading: false,
//       changedContent: "",
//       semanticHtmlString: "",
//       MatchedResults: "",
//       ClearMatchedResults: "",
//       count: 0,
//       showSuccessAlert: false,
//       showFailAlert: false,
//       isButtonDisabled: true,
//       isModal: false,
//       ModalText: "",
//       isSearchDisabled: false,
//       Alertseverity: "",
//       AlertText: "",
//       Alerttitle: "",
//       iscommentModal: "",
//     };
//     this.airnote = React.createRef(null);
//     this.showFile = this.showFile.bind(this);
//   }

//   // componentDidMount() {
//   //   tinymce.init({
//   //     selector: "#airnote",
//   //     menubar: false,
//   //     fixed_toolbar_container: "#css3-selector",
//   //     inline: true,
//   //     plugins: [
//   //       "link",
//   //       "textcolor",
//   //       "lists",
//   //       "powerpaste",
//   //       "linkchecker",
//   //       "contextmenu",
//   //       "autolink",
//   //       "tinymcespellchecker",
//   //       "checklist",
//   //     ],
//   //     toolbar: [
//   //       "undo redo | bold italic underline | fontselect fontsizeselect",
//   //       "forecolor backcolor | alignleft aligncenter alignright alignfull | checklist numlist bullist outdent indent",
//   //     ],
//   //     valid_elements: "p[style],strong,em,span[style],a[href],ul,ol,li",
//   //     valid_styles: {
//   //       "*": "font-size,font-family,color,text-decoration,text-align",
//   //     },
//   //     powerpaste_word_import: "clean",
//   //     powerpaste_html_import: "clean",
//   //     content_css: ["//fonts.googleapis.com/css?family=Lato:300,300i,400,400i"],
//   //   });
//   // }

//   showFile = (e) => {
//     this.setState({
//       selectedFile: e.target.files,
//       isButtonDisabled: false,
//     });
//     e.preventDefault();
//   };
//   function() {
//     document
//       .getElementById("edit")
//       .addEventListener("click", alert("Please select"));
//   }
//   async submit() {
//     this.setState({ isButtonDisabled: true });
//     this.airnote.current.innerHTML = "";
//     const axios = require("axios");
//     const FormData = require("form-data");
//     const data = new FormData();
//     data.append("file", this.state.selectedFile[0]);
//     const config = {
//       method: "post",
//       url: `${REACT_APP_API_BASE_URL}/docx_to_html_str/`,
//       headers: {
//         Accept: "application/json",
//         "Content-Type": "multipart/form-data",
//       },
//       data: data,
//     };

//     try {
//       this.setState({
//         isLoading: true,
//       });
//       const response = await axios(config);
//       // console.log(response, "try");

//       if (response.status === 200) {
//         // console.log(response.data, "response");
//         const myresponse = JSON.stringify(response.data);
//         const content = Object.values(JSON.parse(myresponse))[0];
//         const htmldecode = he.decode(content, {
//           strict: true,
//         });
//         const full_html_string = htmldecode.replace(/\\/g, "");
//         // console.log(full_html_string, "htmldecode");
//         // document.getElementById("airnote").innerHTML += `${full_html_string}`;

//         //html splitter api call

//         const htmlSplitter = new FormData();
//         htmlSplitter.append("full_html_string", full_html_string);
//         const htmlSplitter_config = {
//           method: "post",
//           url: `${REACT_APP_API_BASE_URL}/html_splitter/`,
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "multipart/form-data",
//           },
//           data: htmlSplitter,
//         };

//         const htmlSplitterResponse = await axios(htmlSplitter_config);
//         const htmlSplitterResponseStringify = JSON.stringify(
//           htmlSplitterResponse.data
//         );
//         const style_tag = Object.values(
//           JSON.parse(htmlSplitterResponseStringify)
//         )[0];
//         const head_tag = Object.values(
//           JSON.parse(htmlSplitterResponseStringify)
//         )[1];
//         const body_tag = Object.values(
//           JSON.parse(htmlSplitterResponseStringify)
//         )[2];
//         const html_tag = Object.values(
//           JSON.parse(htmlSplitterResponseStringify)
//         )[3];
//         const style_tag_decode = he.decode(style_tag, {
//           strict: true,
//         });
//         const clean_style_tag = style_tag_decode.replace(/\\/g, "");
//         const body_tag_decode = he.decode(body_tag, {
//           strict: true,
//         });
//         const clean_body_tag = body_tag_decode.replace(/\\/g, "");
//         const head_tag_decode = he.decode(head_tag, {
//           strict: true,
//         });
//         const clean_head_tag = head_tag_decode.replace(/\\/g, "");
//         const html_tag_decode = he.decode(html_tag, {
//           strict: true,
//         });
//         const clean_html_tag = html_tag_decode.replace(/\\/g, "");
//         //Body Styler Api
//         const bodyStyler = new FormData();
//         bodyStyler.append("style_tag", clean_style_tag);
//         bodyStyler.append("body_tag", clean_body_tag);

//         const body_Styler_config = {
//           method: "post",
//           url: `${REACT_APP_API_BASE_URL}/body_styler/`,
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "multipart/form-data",
//           },
//           data: bodyStyler,
//         };
//         const bodyStylerResponse = await axios(body_Styler_config);
//         // console.log(bodyStylerResponse, "bodyStylerResponse");

//         const bodyStylerResponseStringify = JSON.stringify(
//           bodyStylerResponse.data
//         );

//         const bodyStylerData = bodyStylerResponseStringify.replace(
//           /(^"|"$)/g,
//           ""
//         );
//         // console.log(bodyStylerData, "dta");
//         const bodyStylerDataDecoded = he.decode(bodyStylerData, {
//           strict: true,
//         });
//         const cleanedBodyStylerData = bodyStylerDataDecoded.replace(/\\/g, "");
//         // console.log(cleanedBodyStylerData, "cleanedBodyStylerData");

//         //body de styler api

//         const bodyDeStyler = new FormData();
//         bodyDeStyler.append("html_string", cleanedBodyStylerData);

//         const body_De_Styler_config = {
//           method: "post",
//           url: `${REACT_APP_API_BASE_URL}/body_destyler/`,
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "multipart/form-data",
//           },
//           data: bodyDeStyler,
//         };
//         const bodyDeStylerResponse = await axios(body_De_Styler_config);
//         const bodyDestylerResponseStringify = JSON.stringify(
//           bodyDeStylerResponse.data
//         );
//         const bodyDestyler_body_tag = Object.values(
//           JSON.parse(bodyDestylerResponseStringify)
//         )[0];

//         const bodyDeStyler_style_tag = Object.values(
//           JSON.parse(htmlSplitterResponseStringify)
//         )[1];

//         const bodyDestyler_body_tag_decode = he.decode(bodyDestyler_body_tag, {
//           strict: true,
//         });
//         const bodyDestyler_clean_body_tag =
//           bodyDestyler_body_tag_decode.replace(/\\/g, "");

//         const bodyDestyler_style_tag_decode = he.decode(
//           bodyDeStyler_style_tag,
//           {
//             strict: true,
//           }
//         );
//         const bodyDestyler_clean_style_tag =
//           bodyDestyler_style_tag_decode.replace(/\\/g, "");

//         //html_combiner api

//         const htmlCombiner = new FormData();
//         htmlCombiner.append("style_tag", bodyDestyler_clean_style_tag);
//         htmlCombiner.append("body_tag", bodyDestyler_clean_body_tag);

//         htmlCombiner.append("head_tag", clean_head_tag);

//         htmlCombiner.append("html_tag", clean_html_tag);

//         const htmlCombiner_config = {
//           method: "post",
//           url: `${REACT_APP_API_BASE_URL}/html_combiner/`,
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "multipart/form-data",
//           },
//           data: htmlCombiner,
//         };
//         // eslint-disable-next-line no-unused-vars
//         const htmlCombinerResponse = await axios(htmlCombiner_config);

//         // console.log(htmlCombinerResponse, "htmlCombinerResponse");

//         const htmlCombinerData = Object.values(JSON.parse(myresponse))[0];
//         // console.log(htmlCombinerData, "htmlCombinerData");
//         const htmlCombinerDataDecoded = he.decode(htmlCombinerData, {
//           strict: true,
//         });
//         const cleanedhtmlCombinerData = htmlCombinerDataDecoded.replace(
//           /\\/g,
//           ""
//         );
//         // console.log(cleanedhtmlCombinerData, "cleanedhtmlCombinerData");
//         this.setState({
//           isLoading: false,
//         });
//         this.setState({
//           showSuccessAlert: true,
//           Alerttitle: "Success ",
//           Alertseverity: "success",
//           AlertText: "File loaded successfully!",
//         });

//         this.airnote.current.innerHTML += `${cleanedhtmlCombinerData}`;
//         // this.airnote.current.contentEditable = true;
//         const timer = setTimeout(() => {
//           this.setState({
//             showSuccessAlert: false,
//           });
//           clearTimeout(timer);
//         }, 2000);

//         const searchContent = this.airnote.current.innerHTML;
//         // console.log(searchContent, "searchContent");
//       }
//     } catch (err) {
//       this.setState({
//         showFailAlert: true,
//         isLoading: false,
//         isButtonDisabled: false,
//         Alerttitle: "Error ",
//         Alertseverity: "error",
//         AlertText: "Reload file again !",
//       });

//       const timer = setTimeout(() => {
//         this.setState({
//           showFailAlert: false,
//         });
//         clearTimeout(timer);
//       }, 2000);
//       console.log(err);
//     }
//   }

//   async export() {
//     try {
//       this.setState({ isModal: true, ModalText: "Exporting ..." });
//       const axios = require("axios");

//       const current = this.airnote.current.innerHTML;
//       await this.setState(
//         {
//           changedContent: current,
//         },
//         () => {
//           console.log(this.state.changedContent, "changedContent");
//         }
//       );

//       const FormData = require("form-data");
//       const data = new FormData();
//       data.append("filename", this.state.selectedFile[0].name);
//       data.append("html_content", this.state.changedContent);
//       axios
//         .post(`${REACT_APP_API_BASE_URL}/html_str_to_docx/`, data, {
//           responseType: "blob",
//           headers: {
//             Accept: "application/json",
//             "Content-Type": "multipart/form-data",
//           },
//         })
//         .then((response) => {
//           // response.data is an empty object
//           const blob = new Blob([response.data], {
//             type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
//             encoding: "UTF-8",
//           });
//           saveAs(blob, `${this.state.selectedFile[0].name}`);
//           this.setState({
//             isModal: false,
//             showSuccessAlert: true,
//             Alerttitle: "Success ",
//             Alertseverity: "success",
//             AlertText: "Docx file exported successfully",
//           });
//           const timer = setTimeout(() => {
//             this.setState({
//               showSuccessAlert: false,
//             });
//             clearTimeout(timer);
//           }, 2000);
//         })
//         .catch((err) => {
//           this.setState({
//             isModal: false,
//             showFailAlert: true,
//             Alerttitle: "Oops ",
//             Alertseverity: "error",
//             AlertText: "Failed to Export!",
//           });
//           const timer = setTimeout(() => {
//             this.setState({
//               showFailAlert: false,
//             });
//             clearTimeout(timer);
//           }, 2000);
//           console.log(err);
//         });
//     } catch (error) {
//       this.setState({
//         isModal: false,
//         showFailAlert: true,
//         Alerttitle: "Error ",
//         Alertseverity: "error",
//         AlertText: "Reload file again !",
//       });
//       console.log(error);
//     }
//   }

//   Search = async () => {
//     this.setState({
//       isSearchDisabled: true,
//       isModal: true,
//       ModalText: "Mapping ...",
//     });
//     try {
//       const axios = require("axios");
//       const searchContent = this.airnote.current.innerHTML;
//       // console.log(searchContent, "searchContent");
//       const FormData = require("form-data");
//       const SemanticSearch = new FormData();

//       const queries = [...this.props.Queries];
//       console.log(queries, "QueriesQueriesQueriesQueriesQueries");
//       SemanticSearch.append("queries", JSON.stringify(queries));
//       SemanticSearch.append("html_string", searchContent);
//       SemanticSearch.append("algo", "ball_tree");
//       SemanticSearch.append("num_results", 5);
//       const config = {
//         method: "post",
//         url: `${REACT_APP_API_BASE_URL}/semantic_search_v2_with_styles/`,
//         headers: {
//           Accept: "application/json",
//           "Content-Type": "multipart/form-data",
//         },
//         data: SemanticSearch,
//       };
//       const semanticSearchResponse = await axios(config);

//       if (semanticSearchResponse.status === 200) {
//         // console.log(semanticSearchResponse.data, "semanticSearchResponse");

//         const semanticSearchResponseStringified = JSON.stringify(
//           semanticSearchResponse.data
//         );

//         const htmlSections = Object.values(
//           JSON.parse(semanticSearchResponseStringified)
//         )[0]; //html sections
//         // console.log(htmlSections, "htmlSections");
//         const semanticSearchDecode = he.decode(htmlSections, {
//           strict: true,
//         });
//         const htmlSectionsCleanHtml = semanticSearchDecode.replace(/\\/g, "");
//         console.log(htmlSectionsCleanHtml, "htmlSectionsCleanHtml");
//         this.airnote.current.innerHTML = htmlSectionsCleanHtml;

//         await this.setState({
//           MatchedResults: Object.values(
//             JSON.parse(semanticSearchResponseStringified)
//           )[2],
//         });
//         const tags = [...document.querySelectorAll(".results")];
//         const texts = new Set(tags.map((x) => x.innerHTML));
//         tags.forEach((tag) => {
//           if (texts.has(tag.innerHTML)) {
//             texts.delete(tag.innerHTML);
//           } else {
//             tag.remove();
//           }
//         });

//         this.props.getMatches(this.state.MatchedResults);
//         console.log(this.state.MatchedResults);

//         this.setState({
//           isModal: false,
//           showSuccessAlert: true,
//           Alerttitle: "Success ",
//           Alertseverity: "success",
//           AlertText: "Successfully Mapped Results",
//         });
//         const timer = setTimeout(() => {
//           this.setState({
//             showSuccessAlert: false,
//           });
//           clearTimeout(timer);
//         }, 2000);
//       }
//     } catch (error) {
//       this.setState({
//         isSearchDisabled: false,
//         isModal: false,
//         showFailAlert: true,
//         Alerttitle: "Error ",
//         Alertseverity: "error",
//         AlertText: "Mapping Failed",
//       });
//       const timer = setTimeout(() => {
//         this.setState({
//           showFailAlert: false,
//         });
//         clearTimeout(timer);
//       }, 2000);
//       console.log(error);
//     }
//   };
//   Prev = async () => {
//     const k = this.props.queryId;

//     if (
//       this.state.count <= this.state.MatchedResults[`q_${k}`].length &&
//       this.state.count > 0
//     ) {
//       this.setState({
//         count: this.state.count - 1,
//       });
//     }
//     if (this.state.count == 0) {
//       this.setState({
//         count: 4,
//       });
//     }

//     document
//       .getElementById(
//         `${
//           this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count]
//         }`
//       )
//       .scrollIntoView({ behavior: "smooth" });
//     console.log(
//       this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count],
//       "count"
//     );
//   };
//   Next = async () => {
//     const k = this.props.queryId;
//     console.log(this.props.queryId);

//     document
//       .getElementById(
//         `${
//           this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count]
//         }`
//       )
//       .scrollIntoView({ behavior: "smooth" });

//     if (
//       this.state.count >= 0 &&
//       this.state.count < this.state.MatchedResults[`q_${k}`].length - 1
//     ) {
//       this.setState({
//         count: this.state.count + 1,
//       });
//     }
//     if (this.state.count == this.state.MatchedResults[`q_${k}`].length - 1) {
//       this.setState({
//         count: 0,
//       });
//     }
//     console.log(
//       this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count],
//       "count"
//     );
//   };

//   edit = async () => {
//     alert("hiiiii");
//   };

//   render = () => {
//     return (
//       <div>
//         <div className="form-inline my-2 my-lg-0 p-2  ">
//           {this.state.isModal && (
//             <TransitionsModal text={this.state.ModalText} />
//           )}
//           <button
//             type="button"
//             className="btn btn-outline-success my-2 my-sm-0"
//             onClick={this.Search}
//             style={{ marginRight: "10px" }}
//             disabled={this.state.isSearchDisabled}
//           >
//             <i className="fas fa-search"></i>{" "}
//           </button>
//           <button
//             type="button"
//             className="btn btn-outline-success my-2 my-sm-0"
//             onClick={this.Prev}
//             style={{ marginRight: "10px" }}
//           >
//             <i className="fas fa-arrow-left"></i>{" "}
//           </button>
//           <button
//             type="button"
//             className="btn btn-outline-success my-2 my-sm-0"
//             onClick={this.Next}
//             style={{ marginRight: "10px" }}
//           >
//             <i className="fas fa-arrow-right"></i>{" "}
//           </button>
//           <button
//             type="button"
//             className="btn btn-outline-success my-2 my-sm-0"
//             style={{ marginRight: "10px" }}
//           >
//             {this.state.count}/5{" "}
//           </button>{" "}
//         </div>
//         <div style={{ padding: "10px", paddingLeft: "10px" }}>
//           {this.state.showSuccessAlert && (
//             <Alerts
//               Alertseverity={this.state.Alertseverity}
//               AlertText={this.state.AlertText}
//               Alerttitle={this.state.Alerttitle}
//             ></Alerts>
//           )}
//           {this.state.showFailAlert && (
//             <Alerts
//               Alertseverity={this.state.Alertseverity}
//               AlertText={this.state.AlertText}
//               Alerttitle={this.state.Alerttitle}
//             />
//           )}
//           <input
//             type="file"
//             name="files"
//             className="form-group files"
//             onChange={this.showFile}
//             title=" "
//           />
//           <button
//             className="btn btn-info"
//             onClick={() => this.export()}
//             style={{ float: "right" }}
//           >
//             Export
//           </button>
//           <button
//             className="btn btn-info"
//             onClick={() => this.submit()}
//             style={{ float: "right", marginRight: "10px" }}
//             disabled={this.state.isButtonDisabled}
//           >
//             Submit
//           </button>
//         </div>
//         <div
//           style={{
//             height: "  520px",
//             marginLeft: "20px",
//             marginRight: "10px",
//             marginTop: "20px",
//             marginBottom: "20px",
//             overflowY: "auto",
//           }}
//         >
//           <div
//             className=""
//             style={{
//               paddingLeft: "20px",
//               paddingRight: "10px",
//               paddingTop: "20px",
//               paddingBottom: "20px",
//               height: "  500px",
//               overflowY: "auto",
//             }}
//             ref={this.airnote}
//             // suppressContentEditableWarning={true}
//             id="airnote"
//           >
//             {this.state.isLoading && <Loader />}
//           </div>{" "}
//           <button id="edit" onClick={this.edit}>
//             Edit
//           </button>
//         </div>
//       </div>
//     );
//   };
// }

// export default RightHandEditor1;

/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
/* eslint-disable no-console */
import React, { Component } from "react";
import { saveAs } from "file-saver";
import "../index.css";
import "./components.css";
window.Popper = require("popper.js").default;
window.$ = window.jQuery = require("jquery");
const he = require("he");
import Loader from "./Loader";
import TransitionsModal from "./modals/Modal";
import PropTypes from "prop-types";
import Alerts from "./alerts/Alerts";
const { REACT_APP_API_BASE_URL } = process.env;

class RightHandEditor1 extends Component {
  // Handle Prop types
  static propTypes = {
    queryId: PropTypes.string,
    Queries: PropTypes.array,
    getMatches: PropTypes.func,
  };
  constructor() {
    super();
    this.state = {
      name: "React",
      value: "",
      selectedFile: "",
      content1: "",
      fileBase64String: "",
      isLoading: false,
      changedContent: "",
      semanticHtmlString: "",
      MatchedResults: "",
      ClearMatchedResults: "",
      count: 0,
      htmlSectionsArray: [],
      showSuccessAlert: false,
      showFailAlert: false,
      isButtonDisabled: true,
      isModal: false,
      ModalText: "",
      isSearchDisabled: false,
      Alertseverity: "",
      AlertText: "",
      Alerttitle: "",
      iscommentModal: "",
      isRemoveEditorDisabled: false,
      isAddEditorDisabled: false,
    };
    this.airnote = React.createRef(null);
    this.showFile = this.showFile.bind(this);
  }
  // Initializing an Editor
  // componentDidMount() {
  //   tinymce.init({
  //     selector: "#airnote",
  //     menubar: false,
  //     fixed_toolbar_container: "#css3-selector",
  //     inline: true,
  //     plugins: [
  //       "link",
  //       "textcolor",
  //       "lists",
  //       "powerpaste",
  //       "linkchecker",
  //       "contextmenu",
  //       "autolink",
  //       "tinymcespellchecker",
  //       "checklist",
  //     ],
  //     toolbar: [
  //       "undo redo | bold italic underline | fontselect fontsizeselect",
  //       "forecolor backcolor | alignleft aligncenter alignright alignfull | checklist numlist bullist outdent indent",
  //     ],
  //     valid_elements: "p[style],strong,em,span[style],a[href],ul,ol,li",
  //     valid_styles: {
  //       "*": "font-size,font-family,color,text-decoration,text-align",
  //     },
  //     powerpaste_word_import: "clean",
  //     powerpaste_html_import: "clean",
  //     content_css: ["//fonts.googleapis.com/css?family=Lato:300,300i,400,400i"],
  //   });
  // }

  showFile = (e) => {
    this.setState({
      selectedFile: e.target.files,
      isButtonDisabled: false,
    });
    e.preventDefault();
  };
  // Handle Input Docx File via api
  async submit() {
    this.setState({ isButtonDisabled: true });
    this.airnote.current.innerHTML = "";
    const axios = require("axios");
    const FormData = require("form-data");
    const data = new FormData();
    data.append("file", this.state.selectedFile[0]);
    const config = {
      method: "post",
      url: `${REACT_APP_API_BASE_URL}/docx_to_html_str/`,
      headers: {
        Accept: "application/json",
        "Content-Type": "multipart/form-data",
      },
      data: data,
    };

    try {
      this.setState({
        isLoading: true,
      });
      const response = await axios(config);
      // console.log(response, "try");

      if (response.status === 200) {
        // console.log(response.data, "response");
        const myresponse = JSON.stringify(response.data);
        const content = Object.values(JSON.parse(myresponse))[0];
        const htmldecode = he.decode(content, {
          strict: true,
        });
        const full_html_string = htmldecode.replace(/\\/g, "");
        // console.log(full_html_string, "htmldecode");
        // document.getElementById("airnote").innerHTML += `${full_html_string}`;

        //html splitter api call

        const htmlSplitter = new FormData();
        htmlSplitter.append("full_html_string", full_html_string);
        const htmlSplitter_config = {
          method: "post",
          url: `${REACT_APP_API_BASE_URL}/html_splitter/`,
          headers: {
            Accept: "application/json",
            "Content-Type": "multipart/form-data",
          },
          data: htmlSplitter,
        };

        const htmlSplitterResponse = await axios(htmlSplitter_config);
        const htmlSplitterResponseStringify = JSON.stringify(
          htmlSplitterResponse.data
        );
        const style_tag = Object.values(
          JSON.parse(htmlSplitterResponseStringify)
        )[0];
        const head_tag = Object.values(
          JSON.parse(htmlSplitterResponseStringify)
        )[1];
        const body_tag = Object.values(
          JSON.parse(htmlSplitterResponseStringify)
        )[2];
        const html_tag = Object.values(
          JSON.parse(htmlSplitterResponseStringify)
        )[3];
        const style_tag_decode = he.decode(style_tag, {
          strict: true,
        });
        const clean_style_tag = style_tag_decode.replace(/\\/g, "");
        const body_tag_decode = he.decode(body_tag, {
          strict: true,
        });
        const clean_body_tag = body_tag_decode.replace(/\\/g, "");
        const head_tag_decode = he.decode(head_tag, {
          strict: true,
        });
        const clean_head_tag = head_tag_decode.replace(/\\/g, "");
        const html_tag_decode = he.decode(html_tag, {
          strict: true,
        });
        const clean_html_tag = html_tag_decode.replace(/\\/g, "");
        //Body Styler Api
        const bodyStyler = new FormData();
        bodyStyler.append("style_tag", clean_style_tag);
        bodyStyler.append("body_tag", clean_body_tag);

        const body_Styler_config = {
          method: "post",
          url: `${REACT_APP_API_BASE_URL}/body_styler/`,
          headers: {
            Accept: "application/json",
            "Content-Type": "multipart/form-data",
          },
          data: bodyStyler,
        };
        const bodyStylerResponse = await axios(body_Styler_config);
        // console.log(bodyStylerResponse, "bodyStylerResponse");

        const bodyStylerResponseStringify = JSON.stringify(
          bodyStylerResponse.data
        );

        const bodyStylerData = bodyStylerResponseStringify.replace(
          /(^"|"$)/g,
          ""
        );
        // console.log(bodyStylerData, "dta");
        const bodyStylerDataDecoded = he.decode(bodyStylerData, {
          strict: true,
        });
        const cleanedBodyStylerData = bodyStylerDataDecoded.replace(/\\/g, "");
        // console.log(cleanedBodyStylerData, "cleanedBodyStylerData");

        //body de styler api

        const bodyDeStyler = new FormData();
        bodyDeStyler.append("html_string", cleanedBodyStylerData);

        const body_De_Styler_config = {
          method: "post",
          url: `${REACT_APP_API_BASE_URL}/body_destyler/`,
          headers: {
            Accept: "application/json",
            "Content-Type": "multipart/form-data",
          },
          data: bodyDeStyler,
        };
        const bodyDeStylerResponse = await axios(body_De_Styler_config);
        const bodyDestylerResponseStringify = JSON.stringify(
          bodyDeStylerResponse.data
        );
        const bodyDestyler_body_tag = Object.values(
          JSON.parse(bodyDestylerResponseStringify)
        )[0];

        const bodyDeStyler_style_tag = Object.values(
          JSON.parse(htmlSplitterResponseStringify)
        )[1];

        const bodyDestyler_body_tag_decode = he.decode(bodyDestyler_body_tag, {
          strict: true,
        });
        const bodyDestyler_clean_body_tag =
          bodyDestyler_body_tag_decode.replace(/\\/g, "");

        const bodyDestyler_style_tag_decode = he.decode(
          bodyDeStyler_style_tag,
          {
            strict: true,
          }
        );
        const bodyDestyler_clean_style_tag =
          bodyDestyler_style_tag_decode.replace(/\\/g, "");

        //html_combiner api

        const htmlCombiner = new FormData();
        htmlCombiner.append("style_tag", bodyDestyler_clean_style_tag);
        htmlCombiner.append("body_tag", bodyDestyler_clean_body_tag);

        htmlCombiner.append("head_tag", clean_head_tag);

        htmlCombiner.append("html_tag", clean_html_tag);

        const htmlCombiner_config = {
          method: "post",
          url: `${REACT_APP_API_BASE_URL}/html_combiner/`,
          headers: {
            Accept: "application/json",
            "Content-Type": "multipart/form-data",
          },
          data: htmlCombiner,
        };
        // eslint-disable-next-line no-unused-vars
        const htmlCombinerResponse = await axios(htmlCombiner_config);

        // console.log(htmlCombinerResponse, "htmlCombinerResponse");

        const htmlCombinerData = Object.values(JSON.parse(myresponse))[0];
        // console.log(htmlCombinerData, "htmlCombinerData");
        const htmlCombinerDataDecoded = he.decode(htmlCombinerData, {
          strict: true,
        });
        const cleanedhtmlCombinerData = htmlCombinerDataDecoded.replace(
          /\\/g,
          ""
        );
        // console.log(cleanedhtmlCombinerData, "cleanedhtmlCombinerData");
        this.setState({
          isLoading: false,
        });
        this.setState({
          showSuccessAlert: true,
          Alerttitle: "Success ",
          Alertseverity: "success",
          AlertText: "File loaded successfully!",
        });

        this.airnote.current.innerHTML += `${cleanedhtmlCombinerData}`;
        // this.airnote.current.contentEditable = true;
        const timer = setTimeout(() => {
          this.setState({
            showSuccessAlert: false,
          });
          clearTimeout(timer);
        }, 2000);

        const searchContent = this.airnote.current.innerHTML;
        // console.log(searchContent, "searchContent");
      }
    } catch (err) {
      this.setState({
        showFailAlert: true,
        isLoading: false,
        isButtonDisabled: false,
        Alerttitle: "Error ",
        Alertseverity: "error",
        AlertText: "Reload file again !",
      });

      const timer = setTimeout(() => {
        this.setState({
          showFailAlert: false,
        });
        clearTimeout(timer);
      }, 2000);
      console.log(err);
    }
  }
  // Handle Exporting the document
  async export() {
    try {
      this.setState({ isModal: true, ModalText: "Exporting ..." });
      const axios = require("axios");

      const current = this.airnote.current.innerHTML;
      await this.setState(
        {
          changedContent: current,
        },
        () => {
          console.log(this.state.changedContent, "changedContent");
        }
      );

      const FormData = require("form-data");
      const data = new FormData();
      data.append("filename", this.state.selectedFile[0].name);
      data.append("html_content", this.state.changedContent);
      axios
        .post(`${REACT_APP_API_BASE_URL}/html_str_to_docx/`, data, {
          responseType: "blob",
          headers: {
            Accept: "application/json",
            "Content-Type": "multipart/form-data",
          },
        })
        .then((response) => {
          // response.data is an empty object
          const blob = new Blob([response.data], {
            type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            encoding: "UTF-8",
          });
          // Generating a docx file with blob response
          saveAs(blob, `${this.state.selectedFile[0].name}`);
          this.setState({
            isModal: false,
            showSuccessAlert: true,
            Alerttitle: "Success ",
            Alertseverity: "success",
            AlertText: "Docx file exported successfully",
          });
          const timer = setTimeout(() => {
            this.setState({
              showSuccessAlert: false,
            });
            clearTimeout(timer);
          }, 2000);
        })
        .catch((err) => {
          this.setState({
            isModal: false,
            showFailAlert: true,
            Alerttitle: "Oops ",
            Alertseverity: "error",
            AlertText: "Failed to Export!",
          });
          const timer = setTimeout(() => {
            this.setState({
              showFailAlert: false,
            });
            clearTimeout(timer);
          }, 2000);
          console.log(err);
        });
    } catch (error) {
      this.setState({
        isModal: false,
        showFailAlert: true,
        Alerttitle: "Error ",
        Alertseverity: "error",
        AlertText: "Reload file again !",
      });
      const timer = setTimeout(() => {
        this.setState({
          showFailAlert: false,
        });
        clearTimeout(timer);
      }, 2000);
      console.log(error);
    }
  }
  // Semantic search
  Search = async () => {
    this.setState({
      isSearchDisabled: true,
      isModal: true,
      ModalText: "Mapping ...",
    });
    try {
      const axios = require("axios");
      const searchContent = this.airnote.current.innerHTML;
      // console.log(searchContent, "searchContent");
      const FormData = require("form-data");
      const SemanticSearch = new FormData();

      const queries = [...this.props.Queries];
      SemanticSearch.append("queries", JSON.stringify(queries));
      SemanticSearch.append("html_string", searchContent);
      SemanticSearch.append("algo", "ball_tree");
      SemanticSearch.append("num_results", 5);
      const config = {
        method: "post",
        url: `${REACT_APP_API_BASE_URL}/semantic_search_v2_with_styles/`,
        headers: {
          Accept: "application/json",
          "Content-Type": "multipart/form-data",
        },
        data: SemanticSearch,
      };
      const semanticSearchResponse = await axios(config);

      if (semanticSearchResponse.status === 200) {
        this.airnote.current.innerHTML = "";

        // console.log(semanticSearchResponse.data, "semanticSearchResponse");

        const semanticSearchResponseStringified = JSON.stringify(
          semanticSearchResponse.data
        );

        const htmlSections = Object.values(
          JSON.parse(semanticSearchResponseStringified)
        )[0]; //html sections

        this.setState({
          htmlSectionsArray: htmlSections,
        });

        // this.airnote.current.innerHTML = htmlSections.map(
        //   (item, i) =>
        //     // const semanticSearchDecode = he.decode(item, {
        //     //   strict: true,
        //     // });
        //     // const htmlSectionsCleanHtml = semanticSearchDecode.replace(/\\/g, "");

        //     `<div class= results ${i}>` +
        //     item +
        //     `<button id="edit" >
        //         Comment
        //        </button>` +
        //     "</div>"
        // );

        // const semanticSearchDecode = he.decode(
        //   `<div class="results">&lt;div id="r_281" class="results r_281"&gt;&lt;h1 dir="ltr" class="pt-000261"&gt;&lt;span class="pt-000271"&gt;23.&lt;/span&gt;&lt;span class="pt-DefaultParagraphFont-000311"&gt;[Note to draft: Separate signature pages for each of the Existing Investors to be added]&lt;/span&gt;&lt;/h1&gt;&lt;p dir="ltr" class="pt-Normal-000010"&gt;&lt;span xml:space="preserve" class="pt-000312"&gt; &lt;/span&gt;&lt;/p&gt;&lt;/div&gt;<button id="edit" onclick="edit()">
        //         Comment
        //        </button></div>`,
        //   {
        //     strict: true,
        //   }
        // );
        // const htmlSectionsCleanHtml = semanticSearchDecode.replace(/\\/g, "");
        // console.log(htmlSectionsCleanHtml, "htmlSectionsCleanHtml");
        // this.airnote.current.innerHTML = htmlSectionsCleanHtml;

        await this.setState({
          MatchedResults: Object.values(
            JSON.parse(semanticSearchResponseStringified)
          )[2],
        });
        const tags = [...document.querySelectorAll(".queries")];
        const texts = new Set(tags.map((x) => x.innerHTML));
        tags.forEach((tag) => {
          if (texts.has(tag.innerHTML)) {
            texts.delete(tag.innerHTML);
          } else {
            tag.remove();
          }
        });

        this.props.getMatches(this.state.MatchedResults);
        console.log(this.state.MatchedResults);

        this.setState({
          isModal: false,
          showSuccessAlert: true,
          Alerttitle: "Success ",
          Alertseverity: "success",
          AlertText: "Successfully Mapped Results",
        });
        const timer = setTimeout(() => {
          this.setState({
            showSuccessAlert: false,
          });
          clearTimeout(timer);
        }, 2000);
      }
    } catch (error) {
      this.setState({
        isSearchDisabled: false,
        isModal: false,
        showFailAlert: true,
        Alerttitle: "Error ",
        Alertseverity: "error",
        AlertText: "Mapping Failed",
      });
      const timer = setTimeout(() => {
        this.setState({
          showFailAlert: false,
        });
        clearTimeout(timer);
      }, 2000);
      console.log(error);
    }
  };

  Prev = async () => {
    const k = this.props.queryId;

    if (
      this.state.count <= this.state.MatchedResults[`q_${k}`].length &&
      this.state.count > 0
    ) {
      this.setState({
        count: this.state.count - 1,
      });
    }
    if (this.state.count == 0) {
      this.setState({
        count: 4,
      });
    }

    document
      .getElementById(
        `${
          this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count]
        }`
      )
      .scrollIntoView({ behavior: "smooth" });
    console.log(
      this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count],
      "count"
    );
  };
  Next = async () => {
    const k = this.props.queryId;
    console.log(this.props.queryId);

    document
      .getElementById(
        `${
          this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count]
        }`
      )
      .scrollIntoView({ behavior: "smooth" });

    if (
      this.state.count >= 0 &&
      this.state.count < this.state.MatchedResults[`q_${k}`].length - 1
    ) {
      this.setState({
        count: this.state.count + 1,
      });
    }
    if (this.state.count == this.state.MatchedResults[`q_${k}`].length - 1) {
      this.setState({
        count: 0,
      });
    }
    console.log(
      this.state.MatchedResults[`q_${this.props.queryId}`][this.state.count],
      "count"
    );
  };
  AddEditor = async () => {
    document.getElementById("airnote").contentEditable = true;
    this.setState({
      isAddEditorDisabled: true,
      isRemoveEditorDisabled: false,
    });
  };
  RemoveEditor = async () => {
    document.getElementById("airnote").contentEditable = false;
    this.setState({
      isAddEditorDisabled: false,
      isRemoveEditorDisabled: true,
    });
  };
  Comment() {
    alert("Comment");
  }

  render = () => {
    return (
      <div>
        <div className="form-inline my-2 my-lg-0 p-2  ">
          {this.state.isModal && (
            <TransitionsModal text={this.state.ModalText} />
          )}
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            onClick={this.Search}
            style={{ marginRight: "10px" }}
            disabled={this.state.isSearchDisabled}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Search"
          >
            <i className="fas fa-search"></i>{" "}
          </button>
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            onClick={this.Prev}
            style={{ marginRight: "10px" }}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Previous"
          >
            <i className="fas fa-arrow-left"></i>{" "}
          </button>
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            onClick={this.Next}
            style={{ marginRight: "10px" }}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Next"
          >
            <i className="fas fa-arrow-right"></i>{" "}
          </button>
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            style={{ marginRight: "10px" }}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Count"
          >
            {this.state.count}/5{" "}
          </button>{" "}
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            style={{ marginRight: "10px" }}
            onClick={this.AddEditor}
            disabled={this.state.isAddEditorDisabled}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Add Editor"
          >
            <i className="fas fa-edit"></i>{" "}
          </button>{" "}
          <button
            type="button"
            className="btn btn-outline-success my-2 my-sm-0"
            style={{ marginRight: "10px" }}
            onClick={this.RemoveEditor}
            disabled={this.state.isRemoveEditorDisabled}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Remove Editor"
          >
            <i className="fas fa-remove-format"></i>{" "}
          </button>{" "}
        </div>
        <div style={{ padding: "10px", paddingLeft: "10px" }}>
          {this.state.showSuccessAlert && (
            <Alerts
              Alertseverity={this.state.Alertseverity}
              AlertText={this.state.AlertText}
              Alerttitle={this.state.Alerttitle}
            ></Alerts>
          )}
          {this.state.showFailAlert && (
            <Alerts
              Alertseverity={this.state.Alertseverity}
              AlertText={this.state.AlertText}
              Alerttitle={this.state.Alerttitle}
            />
          )}
          <input
            type="file"
            name="files"
            className="form-group files"
            onChange={this.showFile}
            title=" "
          />
          <button
            className="btn btn-info"
            onClick={() => this.export()}
            style={{ float: "right" }}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Export"
          >
            Export
          </button>
          <button
            className="btn btn-info"
            onClick={() => this.submit()}
            style={{ float: "right", marginRight: "10px" }}
            disabled={this.state.isButtonDisabled}
            data-toggle="tooltip"
            data-placement="bottom"
            title="Submit"
          >
            Submit
          </button>
        </div>
        <div
          style={{
            height: "  520px",
            marginLeft: "20px",
            marginRight: "10px",
            marginTop: "20px",
            marginBottom: "20px",
            overflowY: "auto",
          }}
        >
          <div
            className=""
            style={{
              paddingLeft: "20px",
              paddingRight: "10px",
              paddingTop: "20px",
              paddingBottom: "20px",
              height: "  500px",
              overflowY: "auto",
            }}
            ref={this.airnote}
            // suppressContentEditableWarning={true}
            id="airnote"
          >
            {this.state.htmlSectionsArray.map((item, i) => (
              <div className={`${i} results`} key={i}>
                {item}{" "}
                <button id="edit" onClick={this.Comment}>
                  Comment
                </button>
              </div>
            ))}
            {this.state.isLoading && <Loader />}
          </div>{" "}
        </div>
      </div>
    );
  };
}

export default RightHandEditor1;
