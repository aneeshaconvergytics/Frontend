/* eslint-disable react/no-unknown-property */
/* eslint-disable react/jsx-key */
/* eslint-disable no-console */
import React, { Component, Fragment } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import "./components.css";
import $ from "jquery";

class Header extends Component {
  static propTypes = {
    authenticated: PropTypes.bool,
  };
  constructor(props) {
    super(props);
    this.state = {
      file: null,
      queries: "",
      selectValue: "",
      markupStr: "",
    };
  }

  handleChange = (event) => {
    this.setState({ queries: event.target.value });
    this.setState({
      markupStr: JSON.stringify($("#airnote").summernote("code")),
    });
  };

  renderLinks() {
    if (this.props.authenticated) {
      return [
        <nav className="navbar  navbar-expand-lg navbar-light bg-light" key={1}>
          <Link className="navbar-brand" to="#">
            <i className="fab fa-cuttlefish"></i> Contract Mapper
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div
            className="collapse navbar-collapse"
            id="navbarSupportedContent"
            key={2}
          >
            <ul className="navbar-nav ms-auto" key={3}>
              <li className="nav-item active" key={4}>
                <Link className="nav-link" to="/text">
                  <i className="fas fa-home"></i> &nbsp; Home
                  <span className="sr-only">(current)</span>
                </Link>
              </li>

              <li className="nav-item dropdown" key={5}>
                <Link
                  className="nav-link dropdown-toggle active"
                  to="#"
                  id="navbarDropdown"
                  role="button"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="false"
                >
                  <i className="fas fa-bars"></i> &nbsp; Settings
                  <span className="sr-only">(current)</span>
                </Link>
                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                  <Link className="dropdown-item" to="/profile">
                    <i className="far fa-address-card"></i> Profile
                  </Link>

                  <div className="dropdown-divider"></div>
                  <Link className="dropdown-item" to="/">
                    <i className="fas fa-sign-out-alt"></i> Change Password
                  </Link>
                </div>
              </li>
              <li className="nav-item active" key={6}>
                <Link className="nav-link" to="/logout">
                  <i className="fas fa-sign-out-alt"></i> &nbsp; Logout
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
            </ul>
          </div>
        </nav>,
      ];
    } else {
      return [
        <nav
          className="navbar sticky-top navbar-expand-lg navbar-light bg-light"
          key={7}
        >
          <Link className="navbar-brand" to="/">
            <i className="fab fa-cuttlefish"></i> Contract Mapper
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto" key={8}>
              <li className="nav-item active" key={9}>
                <Link className="nav-link" to="/">
                  <i className="fas fa-home"></i> &nbsp; Home
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
              <li className="nav-item active" key={10}>
                <Link className="nav-link" to="/">
                  <i className="fab fa-foursquare"></i> Features
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
              <li className="nav-item active" key={11}>
                <Link className="nav-link" to="/">
                  <i className="far fa-address-card"></i> About
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
              <li className="nav-item active" key={12}>
                <Link className="nav-link" to="/login">
                  <i className="fas fa-sign-in-alt"></i> Login
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
              <li className="nav-item active" key={13}>
                <Link className="nav-link" to="/signup">
                  <i className="far fa-registered"></i> Register
                  <span className="sr-only">(current)</span>
                </Link>
              </li>
            </ul>
          </div>
        </nav>,
      ];
    }
  }

  render() {
    return (
      <Fragment>{this.renderLinks()}</Fragment>
      /* <Link className="navbar-brand" to="#">
          Contract Mapper
        </Link> */
    );
  }
}

function mapStateToProps(state) {
  return {
    authenticated: state.auth.authenticated,
  };
}
export default connect(mapStateToProps)(Header);
