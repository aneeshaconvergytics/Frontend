#!/bin/bash

python manage.py makemigrations user_profile

python manage.py migrate

python manage.py runserver 0.0.0.0:$DJANGO_PORT